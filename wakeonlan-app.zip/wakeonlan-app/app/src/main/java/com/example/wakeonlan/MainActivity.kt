package com.example.wakeonlan

import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

data class Device(val name: String, val mac: String, val ip: String, val port: Int)

class MainActivity : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var etMac: EditText
    private lateinit var etIp: EditText
    private lateinit var etPort: EditText
    private lateinit var lvDevices: ListView

    private val devices = mutableListOf<Device>()
    private lateinit var adapter: ArrayAdapter<String>

    private val prefs by lazy { getSharedPreferences("wol_devices", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etName = findViewById(R.id.etName)
        etMac = findViewById(R.id.etMac)
        etIp = findViewById(R.id.etIp)
        etPort = findViewById(R.id.etPort)
        lvDevices = findViewById(R.id.lvDevices)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        lvDevices.adapter = adapter

        loadDevices()

        findViewById<Button>(R.id.btnWakeNow).setOnClickListener {
            val mac = etMac.text.toString()
            val ip = etIp.text.toString().ifBlank { "255.255.255.255" }
            val port = etPort.text.toString().toIntOrNull() ?: 9
            wake(mac, ip, port)
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val name = etName.text.toString().ifBlank { "Sin nombre" }
            val mac = etMac.text.toString()
            val ip = etIp.text.toString().ifBlank { "255.255.255.255" }
            val port = etPort.text.toString().toIntOrNull() ?: 9

            if (mac.isBlank()) {
                toast("Ingresá una dirección MAC")
                return@setOnClickListener
            }

            devices.add(Device(name, mac, ip, port))
            saveDevices()
            refreshList()
            toast("Dispositivo guardado")
        }

        lvDevices.setOnItemClickListener { _, _, position, _ ->
            val d = devices[position]
            wake(d.mac, d.ip, d.port)
        }

        lvDevices.setOnItemLongClickListener { _, _, position, _ ->
            devices.removeAt(position)
            saveDevices()
            refreshList()
            toast("Dispositivo borrado")
            true
        }
    }

    private fun wake(mac: String, ip: String, port: Int) {
        if (mac.isBlank()) {
            toast("Ingresá una dirección MAC")
            return
        }
        Thread {
            try {
                WakeOnLan.sendMagicPacket(mac, ip, port)
                runOnUiThread { toast("Paquete enviado a $mac") }
            } catch (e: Exception) {
                runOnUiThread { toast("Error: ${e.message}") }
            }
        }.start()
    }

    private fun refreshList() {
        adapter.clear()
        adapter.addAll(devices.map { "${it.name} — ${it.mac} (${it.ip}:${it.port})" })
        adapter.notifyDataSetChanged()
    }

    private fun saveDevices() {
        val arr = JSONArray()
        devices.forEach { d ->
            val obj = JSONObject()
            obj.put("name", d.name)
            obj.put("mac", d.mac)
            obj.put("ip", d.ip)
            obj.put("port", d.port)
            arr.put(obj)
        }
        prefs.edit().putString("devices", arr.toString()).apply()
    }

    private fun loadDevices() {
        devices.clear()
        val raw = prefs.getString("devices", null) ?: run {
            refreshList()
            return
        }
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            devices.add(
                Device(
                    obj.getString("name"),
                    obj.getString("mac"),
                    obj.getString("ip"),
                    obj.getInt("port")
                )
            )
        }
        refreshList()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
