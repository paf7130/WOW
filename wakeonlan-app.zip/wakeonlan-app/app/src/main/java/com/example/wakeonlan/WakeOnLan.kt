package com.example.wakeonlan

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

/**
 * Utilidad para construir y enviar el "Magic Packet" de Wake-on-LAN.
 *
 * El paquete consiste en 6 bytes 0xFF seguidos de la dirección MAC
 * del dispositivo repetida 16 veces, enviado por UDP a la dirección
 * de broadcast de la red (o directamente a la IP del equipo).
 */
object WakeOnLan {

    /**
     * Envía el Magic Packet. Debe llamarse desde un hilo que NO sea el
     * hilo principal (Android no permite I/O de red en el main thread).
     *
     * @param mac dirección MAC en formato "AA:BB:CC:DD:EE:FF" (acepta ':' o '-')
     * @param broadcastIp IP de broadcast, ej "192.168.1.255" o "255.255.255.255"
     * @param port puerto UDP destino (por convención 9, también funciona el 7)
     */
    @Throws(Exception::class)
    fun sendMagicPacket(mac: String, broadcastIp: String, port: Int = 9) {
        val macBytes = parseMac(mac)

        val packet = ByteArray(6 + 16 * 6)
        // 6 bytes de 0xFF
        for (i in 0 until 6) {
            packet[i] = 0xFF.toByte()
        }
        // la MAC repetida 16 veces
        for (i in 0 until 16) {
            System.arraycopy(macBytes, 0, packet, 6 + i * 6, 6)
        }

        val address = InetAddress.getByName(broadcastIp)
        val datagramPacket = DatagramPacket(packet, packet.size, address, port)

        DatagramSocket().use { socket ->
            socket.broadcast = true
            socket.send(datagramPacket)
        }
    }

    /** Convierte "AA:BB:CC:DD:EE:FF" (o con '-') en un ByteArray de 6 bytes. */
    private fun parseMac(mac: String): ByteArray {
        val parts = mac.trim().split(":", "-")
        require(parts.size == 6) { "La MAC debe tener 6 grupos, ej: AA:BB:CC:DD:EE:FF" }
        return ByteArray(6) { i ->
            parts[i].toInt(16).toByte()
        }
    }
}
